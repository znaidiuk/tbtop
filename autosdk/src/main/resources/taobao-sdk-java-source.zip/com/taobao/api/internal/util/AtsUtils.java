package com.taobao.api.internal.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.taobao.api.ApiException;
import com.taobao.api.internal.util.json.JSONReader;

/**
 * 异步API下载工具类。
 * 
 * @author carver.gu
 * @since 1.0, Dec 1, 2010
 */
public abstract class AtsUtils {

	private static final String CTYPE_ZIP = "application/zip";

	private AtsUtils() {}

	public static List<File> unzip(File zipFile) throws IOException {
		List<File> files = new ArrayList<File>();
		ZipFile zip = new ZipFile(zipFile);
		Enumeration<?> entries = zip.entries();
		while (entries.hasMoreElements()) {
			ZipEntry entry = (ZipEntry) entries.nextElement();
			if (entry.isDirectory()) {
				continue;
			}

			File tmp = createTempFile("topats-file-");
			InputStream input = null;
			OutputStream output = null;
			try {
				input = zip.getInputStream(entry);
				output = new FileOutputStream(tmp);
				copy(input, output);
				files.add(tmp);
			} finally {
				closeQuietly(output);
				closeQuietly(input);
			}
		}
		return files;
	}

	public static File download(String url) throws ApiException {
		HttpURLConnection conn = null;
		OutputStream output = null;
		File file = null;
		try {
			conn = getConnection(new URL(url));
			String ctype = conn.getContentType();
			if (CTYPE_ZIP.equals(ctype)) {
				file = createTempFile("topats-zip-");
				output = new FileOutputStream(file);
				copy(conn.getInputStream(), output);
			} else {
				String rsp = WebUtils.getResponseAsString(conn);
				if (!StringUtils.isEmpty(rsp)) {
					JSONReader reader = new JSONReader();
					Object obj = reader.read(rsp);
					if (obj instanceof Map<?, ?>) {
						Map<?, ?> root = (Map<?, ?>) obj;
						String errCode = String.valueOf(root.get("code"));
						String errMsg = String.valueOf(root.get("message"));
						throw new ApiException(errCode, StringUtils.unicodeToChinese(errMsg));
					}
				}
			}
		} catch (IOException e) {
			throw new ApiException(e);
		} finally {
			closeQuietly(output);
			if (conn != null) {
				conn.disconnect();
			}
		}
		return file;
	}

	private static File createTempFile(String prefix) throws IOException {
		return File.createTempFile(prefix, System.currentTimeMillis() + ".txt");
	}

	private static HttpURLConnection getConnection(URL url) throws IOException {
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setDoInput(true);
		conn.setDoOutput(true);
		conn.setRequestProperty("Accept", "application/zip;text/html");
		return conn;
	}

	private static int copy(InputStream input, OutputStream output) throws IOException {
		long count = copyStream(input, output);
		if (count > Integer.MAX_VALUE) {
			return -1;
		}
		return (int) count;
	}

	private static long copyStream(InputStream input, OutputStream output) throws IOException {
		byte[] buffer = new byte[1024];
		long count = 0;
		int n = 0;
		while (-1 != (n = input.read(buffer))) {
			output.write(buffer, 0, n);
			count += n;
		}
		return count;
	}

	private static void closeQuietly(OutputStream output) {
		try {
			if (output != null) {
				output.close();
			}
		} catch (IOException ioe) {
			// ignore
		}
	}

	private static void closeQuietly(InputStream input) {
		try {
			if (input != null) {
				input.close();
			}
		} catch (IOException ioe) {
			// ignore
		}
	}

}
