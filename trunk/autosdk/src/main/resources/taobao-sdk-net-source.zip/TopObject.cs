﻿using System;

namespace Top.Api
{
    /// <summary>
    /// 基础对象。
    /// </summary>
    [Serializable]
    public abstract class TopObject
    {
    }
}
